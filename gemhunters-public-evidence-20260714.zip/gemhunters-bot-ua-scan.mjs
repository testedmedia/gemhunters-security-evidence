import { createHash } from 'node:crypto';
import { writeFile } from 'node:fs/promises';

const url = 'https://gemhunters.co/';
const userAgents = {
  googlebot_ua_string_only: 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
  bingbot_ua_string_only: 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
  applebot_ua_string_only: 'Mozilla/5.0 (compatible; Applebot/0.1; +http://www.apple.com/go/applebot)',
  duckduckbot_ua_string_only: 'DuckDuckBot/1.1; (+http://duckduckgo.com/duckduckbot.html)',
  facebook_preview_ua_string_only: 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)',
  x_preview_ua_string_only: 'Twitterbot/1.0',
  linkedin_preview_ua_string_only: 'LinkedInBot/1.0',
  slack_preview_ua_string_only: 'Slackbot-LinkExpanding 1.0 (+https://api.slack.com/robots)',
  discord_preview_ua_string_only: 'Mozilla/5.0 (compatible; Discordbot/2.0; +https://discordapp.com)',
  telegram_preview_ua_string_only: 'TelegramBot (like TwitterBot)',
};
const markerPatterns = [
  /Just a moment/i,
  /Checking your browser/i,
  /Enable JavaScript and cookies to continue/i,
  /Sorry, you have been blocked/i,
  /Attention Required[^<]*Cloudflare/i,
  /cf-chl-/i,
];
const count = (text, regex) => [...text.matchAll(regex)].length;
const results = [];

for (const [name, userAgent] of Object.entries(userAgents)) {
  const response = await fetch(url, {
    redirect: 'follow',
    headers: {
      'Cache-Control': 'no-cache',
      Pragma: 'no-cache',
      'User-Agent': userAgent,
    },
  });
  const body = await response.text();
  results.push({
    name,
    userAgent,
    requestedUrl: url,
    finalUrl: response.url,
    status: response.status,
    contentType: response.headers.get('content-type'),
    cfCacheStatus: response.headers.get('cf-cache-status'),
    cfMitigated: response.headers.get('cf-mitigated'),
    cfRay: response.headers.get('cf-ray'),
    title: body.match(/<title>([^<]*)<\/title>/i)?.[1] || null,
    challengeMarkers: markerPatterns.filter((pattern) => pattern.test(body)).map(String),
    forms: count(body, /<form\b/gi),
    inputs: count(body, /<input\b/gi),
    passwordFields: count(body, /<input[^>]+type=["']password["']/gi),
    metaRefresh: count(body, /<meta[^>]+http-equiv=["']refresh["']/gi),
    bodyBytes: Buffer.byteLength(body),
    bodySha256: createHash('sha256').update(body).digest('hex'),
  });
}

const report = {
  observedAt: new Date().toISOString(),
  limitation: 'These are user-agent string tests from one network, not verified crawler source IPs.',
  markerPatterns: markerPatterns.map(String),
  summary: {
    caseCount: results.length,
    allHttp200: results.every((item) => item.status === 200),
    allExpectedTitle: results.every((item) => item.title === 'Gem Hunters | Crypto Research Community Since 2017'),
    challengeCaseCount: results.filter((item) => item.challengeMarkers.length > 0).length,
    passwordFieldCaseCount: results.filter((item) => item.passwordFields > 0).length,
  },
  results,
};

const json = JSON.stringify(report, null, 2);
await writeFile(process.env.GH_EVIDENCE_OUT || './gemhunters-bot-ua-scan-results-20260714.json', json);
console.log(json);
