import { createHash } from 'node:crypto';
import { writeFile } from 'node:fs/promises';

const measurementId = process.env.GLOBALPING_MEASUREMENT_ID || '2C1z1cHuorY4Wf2db00020lJL';
const apiUrl = `https://api.globalping.io/v1/measurements/${measurementId}`;
const response = await fetch(apiUrl);
if (!response.ok) throw new Error(`Globalping fetch failed: ${response.status}`);
const measurement = await response.json();
const markerPatterns = [
  /Just a moment/i,
  /Checking your browser/i,
  /Enable JavaScript and cookies to continue/i,
  /Sorry, you have been blocked/i,
  /Attention Required[^<]*Cloudflare/i,
  /cf-chl-/i,
];
const count = (text, regex) => [...text.matchAll(regex)].length;

const results = measurement.results.map(({ probe, result }) => {
  const body = result.rawBody || '';
  return {
    probe: {
      continent: probe.continent,
      region: probe.region,
      country: probe.country,
      state: probe.state,
      city: probe.city,
      asn: probe.asn,
      network: probe.network,
      tags: probe.tags,
    },
    resultStatus: result.status,
    failureMessage: result.statusCode == null ? result.rawOutput : null,
    statusCode: result.statusCode,
    statusCodeName: result.statusCodeName,
    resolvedAddress: result.resolvedAddress,
    contentType: result.headers?.['content-type'] || null,
    cfCacheStatus: result.headers?.['cf-cache-status'] || null,
    cfRay: result.headers?.['cf-ray'] || null,
    title: body.match(/<title>([^<]*)<\/title>/i)?.[1] || null,
    challengeMarkers: markerPatterns.filter((pattern) => pattern.test(body)).map(String),
    forms: count(body, /<form\b/gi),
    inputs: count(body, /<input\b/gi),
    passwordFields: count(body, /<input[^>]+type=["']password["']/gi),
    metaRefresh: count(body, /<meta[^>]+http-equiv=["']refresh["']/gi),
    bodyBytes: Buffer.byteLength(body),
    bodySha256: createHash('sha256').update(body).digest('hex'),
    timings: result.timings,
    tls: {
      authorized: result.tls?.authorized,
      protocol: result.tls?.protocol,
      subject: result.tls?.subject,
      issuer: result.tls?.issuer,
      fingerprint256: result.tls?.fingerprint256,
    },
  };
});

const completedResults = results.filter((item) => item.statusCode != null);

const report = {
  source: 'Globalping by jsDelivr',
  measurementId,
  apiUrl,
  shareUrl: `https://globalping.io/?measurement=${measurementId}`,
  status: measurement.status,
  createdAt: measurement.createdAt,
  updatedAt: measurement.updatedAt,
  requestedTest: {
    type: 'http',
    target: 'gemhunters.co',
    locations: [
      { magic: 'US+eyeball', limit: 2 },
      { magic: 'CA+eyeball', limit: 2 },
      { magic: 'GB+eyeball', limit: 2 },
      { magic: 'DE+eyeball', limit: 2 },
      { magic: 'AU+eyeball', limit: 2 },
      { magic: 'BR+eyeball', limit: 2 },
    ],
    measurementOptions: {
      protocol: 'HTTPS',
      port: 443,
      ipVersion: 6,
      request: {
        method: 'GET',
        path: '/',
        headers: { 'User-Agent': 'security-scanner/1.0 reputation-verification' },
      },
    },
  },
  markerPatterns: markerPatterns.map(String),
  summary: {
    probeCount: results.length,
    countryCount: new Set(results.map((item) => item.probe.country)).size,
    completedHttpProbeCount: completedResults.length,
    probeNoResultCount: results.length - completedResults.length,
    httpFailureCount: completedResults.filter((item) => item.statusCode !== 200).length,
    nativeIpv6FailureCount: completedResults.filter((item) => !item.resolvedAddress?.includes(':')).length,
    expectedTitleFailureCount: completedResults.filter((item) => item.title !== 'Gem Hunters | Crypto Research Community Since 2017').length,
    challengeUrlCount: results.filter((item) => item.challengeMarkers.length > 0).length,
    passwordFieldUrlCount: results.filter((item) => item.passwordFields > 0).length,
    tlsUnauthorizedCount: completedResults.filter((item) => item.tls.authorized !== true).length,
  },
  results,
};

const json = JSON.stringify(report, null, 2);
await writeFile(process.env.GH_EVIDENCE_OUT || './gemhunters-globalping-ipv6-evidence-20260714.json', json);
console.log(json);
