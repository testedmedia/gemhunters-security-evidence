import { writeFile } from 'node:fs/promises';

const origin = 'https://gemhunters.co';
const markerPatterns = [
  /Just a moment/i,
  /Checking your browser/i,
  /Enable JavaScript and cookies to continue/i,
  /Sorry, you have been blocked/i,
  /Attention Required[^<]*Cloudflare/i,
  /cf-chl-/i,
];
const credentialTerms = [
  'seed phrase',
  'recovery phrase',
  'private key',
  'verify your password',
  'enter your password',
  'connect wallet',
  'wallet connect',
  'metamask',
  'wallet drain',
  'drainer',
];

const commonPaths = [
  '/',
  '/?cache_bust=20260714T233000Z',
  '/?utm_source=security-review',
  '/free',
  '/free?step=verify',
  '/cart',
  '/join',
  '/terms',
  '/privacy',
  '/track-record',
  '/login',
  '/signin',
  '/verify',
  '/account',
  '/wallet',
  '/connect',
  '/auth',
  '/admin',
  '/wp-login.php',
  '/.well-known/security.txt',
];

const sitemapResponse = await fetch(`${origin}/sitemap.xml`, {
  headers: { 'User-Agent': 'security-scanner/1.0 reputation-verification' },
});
const sitemapXml = await sitemapResponse.text();
const sitemapPaths = [...sitemapXml.matchAll(/<loc>https:\/\/gemhunters\.co([^<]*)<\/loc>/g)]
  .map((match) => match[1] || '/');
const paths = [...new Set([...commonPaths, ...sitemapPaths])];

const count = (text, regex) => [...text.matchAll(regex)].length;
const findHits = (text, patterns) => patterns.filter((pattern) => pattern.test(text)).map(String);

const results = [];
for (const path of paths) {
  const requestedUrl = `${origin}${path}`;
  try {
    const response = await fetch(requestedUrl, {
      redirect: 'follow',
      headers: {
        'Cache-Control': 'no-cache',
        Pragma: 'no-cache',
        'User-Agent': 'security-scanner/1.0 reputation-verification',
      },
    });
    const html = await response.text();
    const lower = html.toLowerCase();
    results.push({
      requestedUrl,
      finalUrl: response.url,
      status: response.status,
      contentType: response.headers.get('content-type'),
      cacheControl: response.headers.get('cache-control'),
      cfCacheStatus: response.headers.get('cf-cache-status'),
      cfMitigated: response.headers.get('cf-mitigated'),
      cfRay: response.headers.get('cf-ray'),
      title: html.match(/<title>([^<]*)<\/title>/i)?.[1] || null,
      challengeMarkers: findHits(html, markerPatterns),
      forms: count(html, /<form\b/gi),
      inputs: count(html, /<input\b/gi),
      passwordFields: count(html, /<input[^>]+type=["']password["']/gi),
      metaRefresh: count(html, /<meta[^>]+http-equiv=["']refresh["']/gi),
      credentialTermHits: Object.fromEntries(credentialTerms
        .map((term) => [term, lower.split(term).length - 1])
        .filter(([, hits]) => hits > 0)),
    });
  } catch (error) {
    results.push({ requestedUrl, error: String(error) });
  }
}

const report = {
  observedAt: new Date().toISOString(),
  userAgent: 'security-scanner/1.0 reputation-verification',
  markerPatterns: markerPatterns.map(String),
  sitemapStatus: sitemapResponse.status,
  testedUrlCount: results.length,
  results,
};
const json = JSON.stringify(report, null, 2);
await writeFile(process.env.GH_EVIDENCE_OUT || './gemhunters-path-scan-results-20260714.json', json);
console.log(json);
