const url = 'https://gemhunters.co/';
const response = await fetch(url, {
  redirect: 'follow',
  headers: {
    'Cache-Control': 'no-cache',
    Pragma: 'no-cache',
    'User-Agent': 'security-content-review/1.0',
  },
});
const html = await response.text();

const count = (regex) => [...html.matchAll(regex)].length;
const hosts = (attribute) => [...html.matchAll(new RegExp(`${attribute}=["'](https?:\\/\\/[^"' ]+)`, 'gi'))]
  .map((match) => {
    try { return new URL(match[1]).hostname; } catch { return 'invalid-url'; }
  });
const unique = (values) => [...new Set(values)].sort();
const credentialTerms = [
  'seed phrase',
  'recovery phrase',
  'private key',
  'enter your password',
  'verify your password',
  'wallet connect',
  'connect wallet',
  'metamask',
  'wallet drain',
  'drainer',
];
const termHits = Object.fromEntries(credentialTerms.map((term) => [
  term,
  (html.toLowerCase().match(new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length,
]));

console.log(JSON.stringify({
  capturedAt: new Date().toISOString(),
  requestedUrl: url,
  finalUrl: response.url,
  status: response.status,
  contentType: response.headers.get('content-type'),
  title: html.match(/<title>([^<]*)<\/title>/i)?.[1] || null,
  forms: count(/<form\b/gi),
  inputs: count(/<input\b/gi),
  passwordFields: count(/type=["']password["']/gi),
  textareas: count(/<textarea\b/gi),
  literalIframes: count(/<iframe\b/gi),
  metaRefresh: count(/http-equiv=["']refresh["']/gi),
  externalLinkHosts: unique(hosts('href')),
  externalScriptHosts: unique(hosts('src')),
  credentialTermHits: termHits,
}, null, 2));
