#!/bin/bash
set -euo pipefail

urls=(
  'http://gemhunters.co/'
  'http://www.gemhunters.co/'
  'https://gemhunters.co/'
  'https://www.gemhunters.co/'
)

work=$(mktemp -d /tmp/gemhunters-forensics.XXXXXX)
trap 'rm -rf "$work"' EXIT

printf 'captured_utc=%s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
curl --version | sed -n '1,2p'
curl -sS --max-time 20 'https://ipinfo.io/json' | jq '{city,region,country,org,timezone}'

for resolver in 1.1.1.1 8.8.8.8; do
  printf 'resolver=%s A\n' "$resolver"
  dig @"$resolver" gemhunters.co A +noall +answer
  printf 'resolver=%s AAAA\n' "$resolver"
  dig @"$resolver" gemhunters.co AAAA +noall +answer
  printf 'resolver=%s CNAME\n' "$resolver"
  dig @"$resolver" gemhunters.co CNAME +noall +answer
done

openssl s_client -servername gemhunters.co -connect gemhunters.co:443 </dev/null 2>/dev/null \
  | openssl x509 -noout -subject -issuer -serial -dates -ext subjectAltName

for url in "${urls[@]}"; do
  key=$(printf '%s' "$url" | tr -cs 'A-Za-z0-9' '_')
  headers="$work/${key}.headers"
  body="$work/${key}.body"
  metrics=$(curl -4 -sS -L \
    -D "$headers" \
    -o "$body" \
    -w 'final=%{url_effective} code=%{http_code} remote_ip=%{remote_ip} redirects=%{num_redirects} content_type=%{content_type}' \
    --max-time 30 \
    -H 'Cache-Control: no-cache' \
    -H 'Pragma: no-cache' \
    --user-agent 'curl/8.7.1 reputation-verification' \
    "$url")
  ray=$(awk 'BEGIN{IGNORECASE=1}/^cf-ray:/{v=$2} END{gsub(/\r/,"",v);print v}' "$headers")
  mitigated=$(awk 'BEGIN{IGNORECASE=1}/^cf-mitigated:/{v=$2} END{gsub(/\r/,"",v);print v}' "$headers")
  [ -n "$mitigated" ] || mitigated=absent
  if rg -qi '<title>Just a moment|Checking your browser|Enable JavaScript and cookies to continue|Sorry, you have been blocked|Attention Required[^<]*Cloudflare|cf-chl-' "$body"; then body_challenge=present; else body_challenge=absent; fi
  title=$(tr '\n' ' ' < "$body" | sed -n 's/.*<title>\([^<]*\)<\/title>.*/\1/p')
  bytes=$(wc -c < "$body" | tr -d ' ')
  sha=$(shasum -a 256 "$body" | awk '{print $1}')
  printf 'url=%s %s ip_family=IPv4 cf_ray=%s cf_mitigated=%s body_challenge=%s bytes=%s sha256=%s title=%s\n' \
    "$url" "$metrics" "$ray" "$mitigated" "$body_challenge" "$bytes" "$sha" "$title"
done

for n in one two; do
  curl -4 -sS -L \
    -o "$work/$n.html" \
    --max-time 30 \
    -H 'Cache-Control: no-cache' \
    -H 'Pragma: no-cache' \
    --user-agent 'curl/8.7.1 reputation-verification' \
    'https://gemhunters.co/'
  sed -E "s/r:'[a-f0-9]+'/r:'<normalized>'/g; s/t:'[A-Za-z0-9=]+'/t:'<normalized>'/g" \
    "$work/$n.html" > "$work/$n.normalized.html"
done
printf 'raw_body_hashes\n'
shasum -a 256 "$work/one.html" "$work/two.html"
printf 'normalized_body_hashes\n'
shasum -a 256 "$work/one.normalized.html" "$work/two.normalized.html"
printf 'normalized_diff_lines=%s\n' "$(diff -u "$work/one.normalized.html" "$work/two.normalized.html" | wc -l | tr -d ' ')"

for label in googlebot_ua_string_only security_scanner curl_reputation; do
  case "$label" in
    googlebot_ua_string_only) ua='Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)' ;;
    security_scanner) ua='security-scanner/1.0 reputation-verification' ;;
    curl_reputation) ua='curl/8.7.1 reputation-verification' ;;
  esac
  headers="$work/${label}.headers"
  code=$(curl -4 -sS -L \
    -D "$headers" \
    -o /dev/null \
    -w '%{http_code}' \
    --max-time 30 \
    -H 'Cache-Control: no-cache' \
    -H 'Pragma: no-cache' \
    --user-agent "$ua" \
    'https://gemhunters.co/?reputation-check=forensic-script')
  mitigated=$(awk 'BEGIN{IGNORECASE=1}/^cf-mitigated:/{v=$2} END{gsub(/\r/,"",v);print v}' "$headers")
  [ -n "$mitigated" ] || mitigated=absent
  printf 'ua_test=%s code=%s cf_mitigated=%s\n' "$label" "$code" "$mitigated"
done

api_headers="$work/phishdestroy-api.headers"
api_body="$work/phishdestroy-api.json"
curl -sS \
  -D "$api_headers" \
  -o "$api_body" \
  --max-time 30 \
  -H 'Cache-Control: no-cache' \
  -H 'Pragma: no-cache' \
  "https://api.destroy.tools/v1/check?domain=gemhunters.co&reputation_check=$(date -u '+%Y%m%dT%H%M%SZ')"
printf 'api_x_cache=%s api_cache_control=%s api_sha256=%s\n' \
  "$(awk 'BEGIN{IGNORECASE=1}/^x-cache:/{v=$2} END{gsub(/\r/,"",v);print v}' "$api_headers")" \
  "$(awk 'BEGIN{IGNORECASE=1}/^cache-control:/{sub(/^[^:]+:[[:space:]]*/,"");v=$0} END{gsub(/\r/,"",v);print v}' "$api_headers")" \
  "$(shasum -a 256 "$api_body" | awk '{print $1}')"
jq '{domain,threat,severity,risk_score,active,lists,flags,matched_domain,checked_at}' "$api_body"

node "$(dirname "$0")/gemhunters-content-scan.mjs"

printf 'neutral_ipv6_permalink=%s\n' 'https://internet.nl/site/gemhunters.co/4184325/'
printf 'neutral_ipv6_www_permalink=%s\n' 'https://internet.nl/site/www.gemhunters.co/4184367/'
printf 'remote_reader_url=%s\n' 'https://r.jina.ai/http://gemhunters.co/'
